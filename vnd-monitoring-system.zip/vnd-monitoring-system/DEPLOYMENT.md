# Deployment Guide

## 1. Setup Supabase

1. Create account di https://supabase.com
2. Create new project
3. Run SQL files di SQL Editor:
   - `database/01_schema.sql`
   - `database/02_sop_materials.sql`
   - `database/03_sample_data.sql`
4. Copy Project URL dan anon key

## 2. Setup GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/vnd-monitoring.git
git push -u origin main
```

## 3. Deploy to Vercel

1. Go to https://vercel.com
2. Import GitHub repository
3. Add environment variables:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
4. Deploy!

## 4. Post-Deployment

Login dengan:
- Username: `admin`
- Password: `admin123`

Ganti password di Management > User Role

