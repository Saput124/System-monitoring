export default function MasterData() {
  return <div><h1 className="text-2xl font-bold">Master Data</h1></div>
}
