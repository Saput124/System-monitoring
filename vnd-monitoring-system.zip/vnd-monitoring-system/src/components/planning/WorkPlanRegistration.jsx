export default function WorkPlanRegistration() {
  return <div><h1 className="text-2xl font-bold">Work Plan</h1></div>
}
