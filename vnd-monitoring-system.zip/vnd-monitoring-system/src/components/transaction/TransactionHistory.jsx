export default function TransactionHistory() {
  return <div><h1 className="text-2xl font-bold">History</h1></div>
}
