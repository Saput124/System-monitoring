export default function TransactionInput() {
  return <div><h1 className="text-2xl font-bold">Transaction</h1></div>
}
