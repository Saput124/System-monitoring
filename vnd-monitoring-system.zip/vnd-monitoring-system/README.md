# VND Monitoring System

Sistem monitoring aktivitas perkebunan tebu dengan tracking material, vendor, dan progress real-time.

## Features

- ✅ Master Data Management (Blocks, Materials, Activities, Vendors, Workers)
- ✅ Assignment System (Vendor + Activity + Section)
- ✅ Work Plan Registration (2 Tabs: Planning + Material Summary)
- ✅ Transaction Input (Multiple blocks, Partial work)
- ✅ Real-time Progress Dashboard
- ✅ Excel Import/Export
- ✅ Role-based Access (Admin, Section Head, Supervisor, Vendor)

## Tech Stack

- **Frontend**: React + Vite + Tailwind CSS
- **Backend**: Supabase (PostgreSQL)
- **Deployment**: Vercel

## Setup

### 1. Database Setup

Run SQL files in Supabase SQL Editor:

```bash
# 1. Create schema
01_schema.sql

# 2. Insert SOP materials
02_sop_materials.sql

# 3. Insert sample data (optional)
03_sample_data.sql
```

### 2. Environment Variables

Create `.env` file:

```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

### 3. Install Dependencies

```bash
npm install
```

### 4. Run Development Server

```bash
npm run dev
```

### 5. Build for Production

```bash
npm run build
```

## Default Login

```
Username: admin
Password: admin123
```

## Project Structure

```
vnd-monitoring-system/
├── database/
│   ├── 01_schema.sql
│   ├── 02_sop_materials.sql
│   └── 03_sample_data.sql
├── src/
│   ├── components/
│   │   ├── auth/
│   │   │   └── Login.jsx
│   │   ├── master/
│   │   │   ├── MasterData.jsx
│   │   │   └── ImportExcel.jsx
│   │   ├── assignment/
│   │   │   └── Assignment.jsx
│   │   ├── planning/
│   │   │   └── WorkPlanRegistration.jsx
│   │   ├── transaction/
│   │   │   ├── TransactionInput.jsx
│   │   │   └── TransactionHistory.jsx
│   │   └── dashboard/
│   │       └── Dashboard.jsx
│   ├── utils/
│   │   └── supabase.js
│   ├── App.jsx
│   ├── index.css
│   └── main.jsx
├── public/
│   └── templates/
│       ├── import_blocks.xlsx
│       └── import_materials.xlsx
├── package.json
├── vite.config.js
├── tailwind.config.js
└── README.md
```

## Deployment to Vercel

1. Push to GitHub
2. Connect repository to Vercel
3. Add environment variables in Vercel
4. Deploy!

## License

MIT
