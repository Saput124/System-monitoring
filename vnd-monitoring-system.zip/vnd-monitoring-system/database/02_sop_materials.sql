-- ============================================================
-- SOP MATERIAL CONFIGURATION
-- Data dari screenshot Excel
-- ============================================================

-- Insert Activity Stages
INSERT INTO activity_stages (code, name, sequence_order) VALUES
('PRE_EMERGENCE', 'Pre Emergence', 1),
('PRE_EMERGENCE_ALT', 'Pre Emergence Alt', 2),
('LATE_PRE_EMERGENCE', 'Late Pre Emergence', 3),
('LATE_PRE_EMERGENCE_ALT', 'Late Pre Emergence Alt', 4),
('1ST_POST_EARLY', '1st Post Emergence - Early', 5),
('1ST_POST_NORMAL_A', '1st Post Emergence - Normal A', 6),
('1ST_POST_NORMAL_B', '1st Post Emergence - Normal B', 7),
('2ND_POST_ALT1', '2nd Post Emergence - Alt 1', 8),
('2ND_POST_ALT2', '2nd Post Emergence - Alt 2', 9),
('SPOT_SPRAYING', 'Spot Spraying', 10),
('SINGLE_APPLICATION', 'Single Application', 11),
('TOP_DRESSING', 'Top Dressing', 12),
('DRESSING', 'Dressing', 13),
('APLIKASI_DOLOMITE', 'Aplikasi Dolomite', 14);

-- Insert Activity Types
INSERT INTO activity_types (code, name, requires_material, requires_vendor) VALUES
-- Both (Material + Vendor)
('WEED_CONTROL', 'Weed Control (Chemical)', true, true),
('PEST_CONTROL', 'Pest Control (Chemical)', true, true),

-- Material Only
('FERTILIZER_PC', 'Fertilization - Plant Cane', true, false),
('FERTILIZER_RC', 'Fertilization - Ratoon Cane', true, false),
('INSECTICIDE', 'Insecticide Application', true, false),

-- Vendor Only
('WEEDING_MANUAL', 'Weeding Manual', false, true),
('LAND_PREP', 'Land Preparation', false, true),
('HARVEST', 'Harvest', false, true),

-- Report Only (Others)
('INSPECTION', 'Field Inspection', false, false),
('MEASUREMENT', 'Block Measurement', false, false);

-- Insert Materials
INSERT INTO materials (code, name, category, unit) VALUES
-- Herbisida
('AMETRIN', 'Ametrin', 'herbisida', 'liter'),
('2-4-D', '2,4 D', 'herbisida', 'liter'),
('DIURON', 'Diuron', 'herbisida', 'kg'),
('PARAQUAT', 'Paraquat', 'herbisida', 'liter'),
('GLIFOSAT', 'Glifosat', 'herbisida', 'liter'),
('SURFAKTAN', 'Surfaktan', 'herbisida', 'liter'),

-- Pupuk
('UREA', 'Urea 46%', 'pupuk', 'kg'),
('TSP', 'TSP (Triple Super Phosphate)', 'pupuk', 'kg'),
('KCL', 'KCl (Kalium Klorida)', 'pupuk', 'kg'),
('DOLOMITE', 'Dolomite', 'pupuk', 'kg'),
('RP', 'RP (Rock Phosphate)', 'pupuk', 'kg'),

-- Insektisida
('CARBOFURAN', 'Carbofuran', 'insektisida', 'kg'),
('PREVATHION', 'Prevathion', 'insektisida', 'liter');

-- ============================================================
-- WEED CONTROL - TANAMAN PC
-- ============================================================

-- Pre Emergence (PC)
INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'AMETRIN'),
  (SELECT id FROM activity_stages WHERE code = 'PRE_EMERGENCE'),
  'PC', NULL, 2.00, 'liter', true, 1;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = '2-4-D'),
  (SELECT id FROM activity_stages WHERE code = 'PRE_EMERGENCE'),
  'PC', NULL, 2.50, 'liter', true, 2;

-- Pre Emergence Alt (PC)
INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'PARAQUAT'),
  (SELECT id FROM activity_stages WHERE code = 'PRE_EMERGENCE_ALT'),
  'PC', NULL, 0.50, 'liter', true, 1;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'SURFAKTAN'),
  (SELECT id FROM activity_stages WHERE code = 'PRE_EMERGENCE_ALT'),
  'PC', NULL, 0.20, 'liter', false, 2;

-- Late Pre Emergence (PC)
INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'AMETRIN'),
  (SELECT id FROM activity_stages WHERE code = 'LATE_PRE_EMERGENCE'),
  'PC', NULL, 2.00, 'liter', true, 1;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = '2-4-D'),
  (SELECT id FROM activity_stages WHERE code = 'LATE_PRE_EMERGENCE'),
  'PC', NULL, 2.50, 'liter', true, 2;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'PARAQUAT'),
  (SELECT id FROM activity_stages WHERE code = 'LATE_PRE_EMERGENCE'),
  'PC', NULL, 1.50, 'liter', false, 3;

-- 1st Post Emergence - Early (PC)
INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'AMETRIN'),
  (SELECT id FROM activity_stages WHERE code = '1ST_POST_EARLY'),
  'PC', NULL, 2.00, 'liter', true, 1;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = '2-4-D'),
  (SELECT id FROM activity_stages WHERE code = '1ST_POST_EARLY'),
  'PC', NULL, 2.50, 'liter', true, 2;

-- 1st Post Emergence - Normal A (PC)
INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'AMETRIN'),
  (SELECT id FROM activity_stages WHERE code = '1ST_POST_NORMAL_A'),
  'PC', 'Normal A', 2.25, 'liter', true, 1;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = '2-4-D'),
  (SELECT id FROM activity_stages WHERE code = '1ST_POST_NORMAL_A'),
  'PC', 'Normal A', 2.00, 'liter', true, 2;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'PARAQUAT'),
  (SELECT id FROM activity_stages WHERE code = '1ST_POST_NORMAL_A'),
  'PC', 'Normal A', 0.60, 'liter', false, 3;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'SURFAKTAN'),
  (SELECT id FROM activity_stages WHERE code = '1ST_POST_NORMAL_A'),
  'PC', 'Normal A', 0.50, 'liter', false, 4;

-- 1st Post Emergence - Normal B (PC)
INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'AMETRIN'),
  (SELECT id FROM activity_stages WHERE code = '1ST_POST_NORMAL_B'),
  'PC', 'Normal B', 2.00, 'liter', true, 1;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'PARAQUAT'),
  (SELECT id FROM activity_stages WHERE code = '1ST_POST_NORMAL_B'),
  'PC', 'Normal B', 1.50, 'liter', true, 2;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'SURFAKTAN'),
  (SELECT id FROM activity_stages WHERE code = '1ST_POST_NORMAL_B'),
  'PC', 'Normal B', 0.50, 'liter', false, 3;

-- 2nd Post Emergence - Alt 1 (PC)
INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'PARAQUAT'),
  (SELECT id FROM activity_stages WHERE code = '2ND_POST_ALT1'),
  'PC', 'Alt 1', 2.50, 'liter', true, 1;

-- 2nd Post Emergence - Alt 2 (PC)
INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'PARAQUAT'),
  (SELECT id FROM activity_stages WHERE code = '2ND_POST_ALT2'),
  'PC', 'Alt 2', 1.50, 'liter', true, 1;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = '2-4-D'),
  (SELECT id FROM activity_stages WHERE code = '2ND_POST_ALT2'),
  'PC', 'Alt 2', 2.00, 'liter', true, 2;

-- Spot Spraying (PC)
INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'PARAQUAT'),
  (SELECT id FROM activity_stages WHERE code = 'SPOT_SPRAYING'),
  'PC', NULL, 2.00, 'liter', true, 1;

-- ============================================================
-- WEED CONTROL - TANAMAN RC
-- ============================================================

-- Pre Emergence (RC)
INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = '2-4-D'),
  (SELECT id FROM activity_stages WHERE code = 'PRE_EMERGENCE'),
  'RC', NULL, 2.00, 'liter', true, 1;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'DIURON'),
  (SELECT id FROM activity_stages WHERE code = 'PRE_EMERGENCE'),
  'RC', NULL, 2.50, 'kg', true, 2;

-- Late Pre Emergence (RC)
INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'AMETRIN'),
  (SELECT id FROM activity_stages WHERE code = 'LATE_PRE_EMERGENCE'),
  'RC', NULL, 1.50, 'liter', true, 1;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = '2-4-D'),
  (SELECT id FROM activity_stages WHERE code = 'LATE_PRE_EMERGENCE'),
  'RC', NULL, 2.00, 'liter', true, 2;

-- 1st Post Emergence - Early (RC)
INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'AMETRIN'),
  (SELECT id FROM activity_stages WHERE code = '1ST_POST_EARLY'),
  'RC', NULL, 2.00, 'liter', true, 1;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = '2-4-D'),
  (SELECT id FROM activity_stages WHERE code = '1ST_POST_EARLY'),
  'RC', NULL, 2.50, 'liter', true, 2;

-- 1st Post Emergence - Normal A (RC)
INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'AMETRIN'),
  (SELECT id FROM activity_stages WHERE code = '1ST_POST_NORMAL_A'),
  'RC', 'Normal A', 2.25, 'liter', true, 1;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = '2-4-D'),
  (SELECT id FROM activity_stages WHERE code = '1ST_POST_NORMAL_A'),
  'RC', 'Normal A', 2.00, 'liter', true, 2;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'PARAQUAT'),
  (SELECT id FROM activity_stages WHERE code = '1ST_POST_NORMAL_A'),
  'RC', 'Normal A', 0.60, 'liter', false, 3;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'SURFAKTAN'),
  (SELECT id FROM activity_stages WHERE code = '1ST_POST_NORMAL_A'),
  'RC', 'Normal A', 0.50, 'liter', false, 4;

-- 1st Post Emergence - Normal B (RC)
INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'AMETRIN'),
  (SELECT id FROM activity_stages WHERE code = '1ST_POST_NORMAL_B'),
  'RC', 'Normal B', 2.00, 'liter', true, 1;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'PARAQUAT'),
  (SELECT id FROM activity_stages WHERE code = '1ST_POST_NORMAL_B'),
  'RC', 'Normal B', 2.00, 'liter', true, 2;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'SURFAKTAN'),
  (SELECT id FROM activity_stages WHERE code = '1ST_POST_NORMAL_B'),
  'RC', 'Normal B', 0.50, 'liter', false, 3;

-- 2nd Post Emergence - Alt 1 (RC)
INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'PARAQUAT'),
  (SELECT id FROM activity_stages WHERE code = '2ND_POST_ALT1'),
  'RC', 'Alt 1', 2.50, 'liter', true, 1;

-- 2nd Post Emergence - Alt 2 (RC)
INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'PARAQUAT'),
  (SELECT id FROM activity_stages WHERE code = '2ND_POST_ALT2'),
  'RC', 'Alt 2', 1.50, 'liter', true, 1;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = '2-4-D'),
  (SELECT id FROM activity_stages WHERE code = '2ND_POST_ALT2'),
  'RC', 'Alt 2', 2.00, 'liter', true, 2;

-- Spot Spraying (RC)
INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM materials WHERE code = 'PARAQUAT'),
  (SELECT id FROM activity_stages WHERE code = 'SPOT_SPRAYING'),
  'RC', NULL, 2.00, 'liter', true, 1;

-- ============================================================
-- INSEKTISIDA
-- ============================================================

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'INSECTICIDE'),
  (SELECT id FROM materials WHERE code = 'PREVATHION'),
  NULL, NULL, NULL, 1.00, 'liter', true, 1;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'INSECTICIDE'),
  (SELECT id FROM materials WHERE code = 'CARBOFURAN'),
  NULL, NULL, NULL, 30.00, 'kg', true, 2;

-- ============================================================
-- PUPUK - PLANT CANE
-- ============================================================

-- Top Dressing PC
INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'FERTILIZER_PC'),
  (SELECT id FROM materials WHERE code = 'UREA'),
  (SELECT id FROM activity_stages WHERE code = 'TOP_DRESSING'),
  'PC', NULL, 400.00, 'kg', true, 1;

-- Dressing PC
INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'FERTILIZER_PC'),
  (SELECT id FROM materials WHERE code = 'TSP'),
  (SELECT id FROM activity_stages WHERE code = 'DRESSING'),
  'PC', NULL, 300.00, 'kg', true, 1;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'FERTILIZER_PC'),
  (SELECT id FROM materials WHERE code = 'KCL'),
  (SELECT id FROM activity_stages WHERE code = 'DRESSING'),
  'PC', NULL, 300.00, 'kg', true, 2;

-- Aplikasi Dolomite PC
INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'FERTILIZER_PC'),
  (SELECT id FROM materials WHERE code = 'DOLOMITE'),
  (SELECT id FROM activity_stages WHERE code = 'APLIKASI_DOLOMITE'),
  'PC', NULL, 1.50, 'kg', true, 1;

-- ============================================================
-- PUPUK - RATOON CANE
-- ============================================================

-- Single Application RC
INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'FERTILIZER_RC'),
  (SELECT id FROM materials WHERE code = 'UREA'),
  (SELECT id FROM activity_stages WHERE code = 'SINGLE_APPLICATION'),
  'RC', NULL, 300.00, 'kg', true, 1;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'FERTILIZER_RC'),
  (SELECT id FROM materials WHERE code = 'TSP'),
  (SELECT id FROM activity_stages WHERE code = 'SINGLE_APPLICATION'),
  'RC', NULL, 150.00, 'kg', true, 2;

INSERT INTO activity_materials (activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option, default_dosis, unit, required, display_order)
SELECT 
  (SELECT id FROM activity_types WHERE code = 'FERTILIZER_RC'),
  (SELECT id FROM materials WHERE code = 'KCL'),
  (SELECT id FROM activity_stages WHERE code = 'SINGLE_APPLICATION'),
  'RC', NULL, 300.00, 'kg', true, 3;

-- ============================================================
-- DONE! SOP Material lengkap
-- ============================================================
