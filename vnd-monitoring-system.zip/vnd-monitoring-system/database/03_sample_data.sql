-- ============================================================
-- SAMPLE DATA FOR TESTING
-- ============================================================

-- Insert Sections
INSERT INTO sections (code, name, description) VALUES
('AFD1', 'Afdeling 1', 'Kebun Zona A'),
('AFD2', 'Afdeling 2', 'Kebun Zona B'),
('AFD3', 'Afdeling 3', 'Kebun Zona C');

-- Insert Vendors
INSERT INTO vendors (code, name, contact_person, phone) VALUES
('V001', 'PT Mitra Tani', 'Budi Santoso', '081234567890'),
('V002', 'CV Karya Mandiri', 'Siti Aminah', '081234567891'),
('V003', 'UD Sejahtera', 'Ahmad Yani', '081234567892');

-- Insert Users (Admin)
INSERT INTO users (username, password, full_name, role, section_id, vendor_id) VALUES
('admin', 'admin123', 'Administrator', 'admin', NULL, NULL);

-- Insert Users (Section Heads)
INSERT INTO users (username, password, full_name, role, section_id, vendor_id)
SELECT 
  'kasi' || ROW_NUMBER() OVER(),
  'password123',
  'Kepala Afdeling ' || ROW_NUMBER() OVER(),
  'section_head',
  id,
  NULL
FROM sections;

-- Insert Users (Vendors)
INSERT INTO users (username, password, full_name, role, section_id, vendor_id)
SELECT 
  'vendor' || ROW_NUMBER() OVER(),
  'password123',
  'User ' || name,
  'vendor',
  NULL,
  id
FROM vendors;

-- Insert Blocks
INSERT INTO blocks (kawasan, code, name, luas_total, kategori, varietas) VALUES
-- Zona A
('Zona A', 'A01', 'Blok A-01', 2.50, 'PC', 'PS-881'),
('Zona A', 'A02', 'Blok A-02', 3.00, 'PC', 'PSJT-941'),
('Zona A', 'A03', 'Blok A-03', 2.00, 'RC', 'PS-881'),
('Zona A', 'A04', 'Blok A-04', 4.50, 'RC', 'Bululawang'),
('Zona A', 'A05', 'Blok A-05', 3.50, 'PC', 'PS-881'),

-- Zona B
('Zona B', 'B01', 'Blok B-01', 4.00, 'RC', 'PS-881'),
('Zona B', 'B02', 'Blok B-02', 3.20, 'PC', 'PSJT-941'),
('Zona B', 'B03', 'Blok B-03', 2.80, 'PC', 'PS-881'),
('Zona B', 'B04', 'Blok B-04', 5.00, 'RC', 'Bululawang'),
('Zona B', 'B05', 'Blok B-05', 2.50, 'PC', 'PSJT-941'),

-- Zona C
('Zona C', 'C01', 'Blok C-01', 3.80, 'PC', 'PS-881'),
('Zona C', 'C02', 'Blok C-02', 4.20, 'RC', 'PS-881'),
('Zona C', 'C03', 'Blok C-03', 2.60, 'PC', 'PSJT-941'),
('Zona C', 'C04', 'Blok C-04', 3.40, 'RC', 'Bululawang'),
('Zona C', 'C05', 'Blok C-05', 4.80, 'PC', 'PS-881');

-- Insert Workers for Vendor 1
INSERT INTO workers (vendor_id, code, name, phone)
SELECT 
  (SELECT id FROM vendors WHERE code = 'V001'),
  'W001-' || LPAD(generate_series::text, 3, '0'),
  'Pekerja V001 ' || generate_series,
  '0812345678' || LPAD(generate_series::text, 2, '0')
FROM generate_series(1, 30);

-- Insert Workers for Vendor 2
INSERT INTO workers (vendor_id, code, name, phone)
SELECT 
  (SELECT id FROM vendors WHERE code = 'V002'),
  'W002-' || LPAD(generate_series::text, 3, '0'),
  'Pekerja V002 ' || generate_series,
  '0812345679' || LPAD(generate_series::text, 2, '0')
FROM generate_series(1, 25);

-- Insert Workers for Vendor 3
INSERT INTO workers (vendor_id, code, name, phone)
SELECT 
  (SELECT id FROM vendors WHERE code = 'V003'),
  'W003-' || LPAD(generate_series::text, 3, '0'),
  'Pekerja V003 ' || generate_series,
  '0812345680' || LPAD(generate_series::text, 2, '0')
FROM generate_series(1, 20);

-- ============================================================
-- ASSIGNMENT: Section Activities
-- ============================================================

-- Afdeling 1 dapat semua activities
INSERT INTO section_activities (section_id, activity_type_id)
SELECT 
  (SELECT id FROM sections WHERE code = 'AFD1'),
  id
FROM activity_types;

-- Afdeling 2 dapat weed control, fertilizer, weeding manual
INSERT INTO section_activities (section_id, activity_type_id)
SELECT 
  (SELECT id FROM sections WHERE code = 'AFD2'),
  id
FROM activity_types
WHERE code IN ('WEED_CONTROL', 'FERTILIZER_PC', 'FERTILIZER_RC', 'WEEDING_MANUAL', 'INSPECTION');

-- Afdeling 3 dapat fertilizer, harvest, inspection
INSERT INTO section_activities (section_id, activity_type_id)
SELECT 
  (SELECT id FROM sections WHERE code = 'AFD3'),
  id
FROM activity_types
WHERE code IN ('FERTILIZER_PC', 'FERTILIZER_RC', 'HARVEST', 'INSPECTION', 'MEASUREMENT');

-- ============================================================
-- ASSIGNMENT: Vendor Assignments
-- ============================================================

-- Vendor 1: AFD1 - Weed Control
INSERT INTO vendor_assignments (vendor_id, section_id, activity_type_id)
SELECT 
  (SELECT id FROM vendors WHERE code = 'V001'),
  (SELECT id FROM sections WHERE code = 'AFD1'),
  id
FROM activity_types
WHERE code IN ('WEED_CONTROL', 'PEST_CONTROL');

-- Vendor 1: AFD2 - Weed Control
INSERT INTO vendor_assignments (vendor_id, section_id, activity_type_id)
SELECT 
  (SELECT id FROM vendors WHERE code = 'V001'),
  (SELECT id FROM sections WHERE code = 'AFD2'),
  id
FROM activity_types
WHERE code = 'WEED_CONTROL';

-- Vendor 2: AFD1 - Weeding Manual
INSERT INTO vendor_assignments (vendor_id, section_id, activity_type_id)
SELECT 
  (SELECT id FROM vendors WHERE code = 'V002'),
  (SELECT id FROM sections WHERE code = 'AFD1'),
  id
FROM activity_types
WHERE code IN ('WEEDING_MANUAL', 'LAND_PREP');

-- Vendor 2: AFD2 - Weeding Manual
INSERT INTO vendor_assignments (vendor_id, section_id, activity_type_id)
SELECT 
  (SELECT id FROM vendors WHERE code = 'V002'),
  (SELECT id FROM sections WHERE code = 'AFD2'),
  id
FROM activity_types
WHERE code = 'WEEDING_MANUAL';

-- Vendor 3: AFD3 - Harvest
INSERT INTO vendor_assignments (vendor_id, section_id, activity_type_id)
SELECT 
  (SELECT id FROM vendors WHERE code = 'V003'),
  (SELECT id FROM sections WHERE code = 'AFD3'),
  id
FROM activity_types
WHERE code = 'HARVEST';

-- ============================================================
-- SAMPLE REGISTRASI (Planning)
-- ============================================================

-- Activity Plan 1: Weed Control - AFD1 - Januari 2026
INSERT INTO activity_plans (section_id, activity_type_id, vendor_id, target_bulan, stage_id, alternative_option, status, created_by)
SELECT 
  (SELECT id FROM sections WHERE code = 'AFD1'),
  (SELECT id FROM activity_types WHERE code = 'WEED_CONTROL'),
  (SELECT id FROM vendors WHERE code = 'V001'),
  '2026-01-01',
  (SELECT id FROM activity_stages WHERE code = '1ST_POST_NORMAL_A'),
  'Normal A',
  'approved',
  (SELECT id FROM users WHERE username = 'admin');

-- Block Activities untuk Plan 1
INSERT INTO block_activities (activity_plan_id, block_id, luas_total, luas_remaining, status)
SELECT 
  (SELECT id FROM activity_plans WHERE target_bulan = '2026-01-01' AND section_id = (SELECT id FROM sections WHERE code = 'AFD1') LIMIT 1),
  id,
  luas_total,
  luas_total,
  'planned'
FROM blocks
WHERE kawasan = 'Zona A'
LIMIT 5;

-- Planned Materials untuk Plan 1
INSERT INTO planned_materials (activity_plan_id, material_id, total_quantity, unit)
SELECT 
  ap.id,
  am.material_id,
  SUM(ba.luas_total * am.default_dosis),
  am.unit
FROM activity_plans ap
JOIN block_activities ba ON ba.activity_plan_id = ap.id
JOIN blocks b ON b.id = ba.block_id
JOIN activity_materials am ON am.activity_type_id = ap.activity_type_id 
  AND am.stage_id = ap.stage_id
  AND (am.tanaman_kategori = b.kategori OR am.tanaman_kategori IS NULL)
  AND (am.alternative_option = ap.alternative_option OR am.alternative_option IS NULL)
WHERE ap.target_bulan = '2026-01-01' 
  AND ap.section_id = (SELECT id FROM sections WHERE code = 'AFD1')
GROUP BY ap.id, am.material_id, am.unit;

-- Activity Plan 2: Fertilizer PC - AFD1 - Januari 2026
INSERT INTO activity_plans (section_id, activity_type_id, vendor_id, target_bulan, stage_id, status, created_by)
SELECT 
  (SELECT id FROM sections WHERE code = 'AFD1'),
  (SELECT id FROM activity_types WHERE code = 'FERTILIZER_PC'),
  NULL, -- Material only
  '2026-01-01',
  (SELECT id FROM activity_stages WHERE code = 'TOP_DRESSING'),
  'approved',
  (SELECT id FROM users WHERE username = 'admin');

-- Block Activities untuk Plan 2 (hanya PC blocks)
INSERT INTO block_activities (activity_plan_id, block_id, luas_total, luas_remaining, status)
SELECT 
  (SELECT id FROM activity_plans WHERE target_bulan = '2026-01-01' AND activity_type_id = (SELECT id FROM activity_types WHERE code = 'FERTILIZER_PC') LIMIT 1),
  id,
  luas_total,
  luas_total,
  'planned'
FROM blocks
WHERE kawasan = 'Zona A' AND kategori = 'PC'
LIMIT 3;

-- Planned Materials untuk Plan 2
INSERT INTO planned_materials (activity_plan_id, material_id, total_quantity, unit)
SELECT 
  ap.id,
  am.material_id,
  SUM(ba.luas_total * am.default_dosis),
  am.unit
FROM activity_plans ap
JOIN block_activities ba ON ba.activity_plan_id = ap.id
JOIN blocks b ON b.id = ba.block_id
JOIN activity_materials am ON am.activity_type_id = ap.activity_type_id 
  AND am.stage_id = ap.stage_id
  AND (am.tanaman_kategori = b.kategori OR am.tanaman_kategori IS NULL)
WHERE ap.target_bulan = '2026-01-01' 
  AND ap.activity_type_id = (SELECT id FROM activity_types WHERE code = 'FERTILIZER_PC')
GROUP BY ap.id, am.material_id, am.unit;

-- ============================================================
-- SAMPLE TRANSAKSI
-- ============================================================

-- Transaksi 1: Blok A01 - Partial (1.5 Ha dari 2.5 Ha)
INSERT INTO transactions (block_activity_id, tanggal, luas_dikerjakan, jumlah_pekerja, created_by)
SELECT 
  ba.id,
  '2026-01-05',
  1.5,
  15,
  (SELECT id FROM users WHERE username = 'admin')
FROM block_activities ba
JOIN blocks b ON b.id = ba.block_id
WHERE b.code = 'A01'
  AND ba.status = 'planned'
LIMIT 1;

-- Transaction Materials untuk Transaksi 1
INSERT INTO transaction_materials (transaction_id, material_id, quantity_used, unit)
SELECT 
  t.id,
  m.id,
  CASE 
    WHEN m.code = 'AMETRIN' THEN 3.375  -- 2.25 × 1.5
    WHEN m.code = '2-4-D' THEN 3.000    -- 2.00 × 1.5
    WHEN m.code = 'PARAQUAT' THEN 0.900 -- 0.60 × 1.5
  END,
  CASE 
    WHEN m.code IN ('AMETRIN', '2-4-D', 'PARAQUAT') THEN 'liter'
  END
FROM transactions t
JOIN block_activities ba ON ba.id = t.block_activity_id
JOIN blocks b ON b.id = ba.block_id
CROSS JOIN materials m
WHERE b.code = 'A01'
  AND t.tanggal = '2026-01-05'
  AND m.code IN ('AMETRIN', '2-4-D', 'PARAQUAT');

-- Transaction Workers untuk Transaksi 1 (manual count)
INSERT INTO transaction_workers (transaction_id, worker_id, jumlah_manual)
SELECT 
  t.id,
  NULL,
  15
FROM transactions t
JOIN block_activities ba ON ba.id = t.block_activity_id
JOIN blocks b ON b.id = ba.block_id
WHERE b.code = 'A01'
  AND t.tanggal = '2026-01-05';

-- Transaksi 2: Blok A02 - Complete (3.0 Ha)
INSERT INTO transactions (block_activity_id, tanggal, luas_dikerjakan, jumlah_pekerja, created_by)
SELECT 
  ba.id,
  '2026-01-06',
  3.0,
  20,
  (SELECT id FROM users WHERE username = 'admin')
FROM block_activities ba
JOIN blocks b ON b.id = ba.block_id
WHERE b.code = 'A02'
  AND ba.status = 'planned'
LIMIT 1;

-- Transaction Materials untuk Transaksi 2
INSERT INTO transaction_materials (transaction_id, material_id, quantity_used, unit)
SELECT 
  t.id,
  m.id,
  CASE 
    WHEN m.code = 'AMETRIN' THEN 6.750  -- 2.25 × 3.0
    WHEN m.code = '2-4-D' THEN 6.000    -- 2.00 × 3.0
  END,
  'liter'
FROM transactions t
JOIN block_activities ba ON ba.id = t.block_activity_id
JOIN blocks b ON b.id = ba.block_id
CROSS JOIN materials m
WHERE b.code = 'A02'
  AND t.tanggal = '2026-01-06'
  AND m.code IN ('AMETRIN', '2-4-D');

-- Transaction Workers untuk Transaksi 2
INSERT INTO transaction_workers (transaction_id, worker_id, jumlah_manual)
SELECT 
  t.id,
  NULL,
  20
FROM transactions t
JOIN block_activities ba ON ba.id = t.block_activity_id
JOIN blocks b ON b.id = ba.block_id
WHERE b.code = 'A02'
  AND t.tanggal = '2026-01-06';

-- ============================================================
-- DONE! Sample data ready for testing
-- ============================================================

-- Verify data
SELECT 'Sections' as table_name, COUNT(*) as count FROM sections
UNION ALL
SELECT 'Users', COUNT(*) FROM users
UNION ALL
SELECT 'Vendors', COUNT(*) FROM vendors
UNION ALL
SELECT 'Blocks', COUNT(*) FROM blocks
UNION ALL
SELECT 'Workers', COUNT(*) FROM workers
UNION ALL
SELECT 'Activity Types', COUNT(*) FROM activity_types
UNION ALL
SELECT 'Materials', COUNT(*) FROM materials
UNION ALL
SELECT 'Activity Materials (SOP)', COUNT(*) FROM activity_materials
UNION ALL
SELECT 'Section Activities', COUNT(*) FROM section_activities
UNION ALL
SELECT 'Vendor Assignments', COUNT(*) FROM vendor_assignments
UNION ALL
SELECT 'Activity Plans', COUNT(*) FROM activity_plans
UNION ALL
SELECT 'Block Activities', COUNT(*) FROM block_activities
UNION ALL
SELECT 'Planned Materials', COUNT(*) FROM planned_materials
UNION ALL
SELECT 'Transactions', COUNT(*) FROM transactions
UNION ALL
SELECT 'Transaction Materials', COUNT(*) FROM transaction_materials
UNION ALL
SELECT 'Transaction Workers', COUNT(*) FROM transaction_workers;
