-- ============================================================
-- VND MONITORING SYSTEM - COMPLETE DATABASE SCHEMA
-- Fresh Build - Zero to Hero
-- ============================================================

-- Enable UUID Extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- PART 1: MASTER DATA TABLES
-- ============================================================

-- 1. SECTIONS (Unit TIM)
CREATE TABLE sections (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_sections_code ON sections(code);

-- 2. USERS (Username/Password - NO EMAIL!)
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  username VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL, -- Plain password atau hash sederhana
  full_name VARCHAR(255) NOT NULL,
  role VARCHAR(50) NOT NULL CHECK (role IN ('admin', 'section_head', 'supervisor', 'vendor')),
  section_id UUID REFERENCES sections(id) NULL, -- NULL untuk admin dan vendor
  vendor_id UUID NULL, -- Will reference vendors(id), untuk role vendor
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_role ON users(role);

-- 3. VENDORS
CREATE TABLE vendors (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  contact_person VARCHAR(255),
  phone VARCHAR(50),
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_vendors_code ON vendors(code);

-- 4. BLOCKS (Kawasan, Code, Name, Luas, Kategori, Varietas)
CREATE TABLE blocks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  kawasan VARCHAR(100) NOT NULL,
  code VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  luas_total DECIMAL(10,2) NOT NULL,
  kategori VARCHAR(20) NOT NULL CHECK (kategori IN ('PC', 'RC')),
  varietas VARCHAR(100),
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_blocks_kawasan ON blocks(kawasan);
CREATE INDEX idx_blocks_kategori ON blocks(kategori);
CREATE INDEX idx_blocks_code ON blocks(code);

-- 5. WORKERS
CREATE TABLE workers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  vendor_id UUID REFERENCES vendors(id) ON DELETE CASCADE,
  code VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  phone VARCHAR(50),
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_workers_vendor ON workers(vendor_id);
CREATE INDEX idx_workers_code ON workers(code);

-- ============================================================
-- PART 2: ACTIVITY & MATERIAL CONFIGURATION
-- ============================================================

-- 6. ACTIVITY TYPES
CREATE TABLE activity_types (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  requires_material BOOLEAN DEFAULT false,
  requires_vendor BOOLEAN DEFAULT true,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_activity_types_code ON activity_types(code);

COMMENT ON TABLE activity_types IS 'Jenis aktivitas: material+vendor, material only, vendor only, report only';
COMMENT ON COLUMN activity_types.requires_material IS 'True jika butuh material (herbisida, pupuk, dll)';
COMMENT ON COLUMN activity_types.requires_vendor IS 'True jika butuh vendor';

-- 7. ACTIVITY STAGES
CREATE TABLE activity_stages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  sequence_order INTEGER,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_activity_stages_sequence ON activity_stages(sequence_order);

-- 8. MATERIALS
CREATE TABLE materials (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  category VARCHAR(50) NOT NULL CHECK (category IN ('herbisida', 'pestisida', 'pupuk', 'insektisida', 'alat', 'lainnya')),
  unit VARCHAR(20) NOT NULL,
  manufacturer VARCHAR(255),
  description TEXT,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_materials_code ON materials(code);
CREATE INDEX idx_materials_category ON materials(category);

-- 9. ACTIVITY MATERIALS (SOP Material Configuration)
CREATE TABLE activity_materials (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  activity_type_id UUID NOT NULL REFERENCES activity_types(id) ON DELETE CASCADE,
  material_id UUID NOT NULL REFERENCES materials(id) ON DELETE CASCADE,
  stage_id UUID REFERENCES activity_stages(id) ON DELETE SET NULL,
  tanaman_kategori VARCHAR(20) CHECK (tanaman_kategori IN ('PC', 'RC')),
  alternative_option VARCHAR(50),
  default_dosis DECIMAL(10,3) NOT NULL,
  unit VARCHAR(20) NOT NULL,
  required BOOLEAN DEFAULT false,
  display_order INTEGER DEFAULT 0,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(activity_type_id, material_id, stage_id, tanaman_kategori, alternative_option)
);

CREATE INDEX idx_activity_materials_activity ON activity_materials(activity_type_id);
CREATE INDEX idx_activity_materials_material ON activity_materials(material_id);
CREATE INDEX idx_activity_materials_stage ON activity_materials(stage_id);
CREATE INDEX idx_activity_materials_kategori ON activity_materials(tanaman_kategori);

-- ============================================================
-- PART 3: ASSIGNMENT TABLES
-- ============================================================

-- 10. SECTION ACTIVITIES (Section punya activities apa)
CREATE TABLE section_activities (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  section_id UUID NOT NULL REFERENCES sections(id) ON DELETE CASCADE,
  activity_type_id UUID NOT NULL REFERENCES activity_types(id) ON DELETE CASCADE,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(section_id, activity_type_id)
);

CREATE INDEX idx_section_activities_section ON section_activities(section_id);
CREATE INDEX idx_section_activities_activity ON section_activities(activity_type_id);

-- 11. VENDOR ASSIGNMENTS (Vendor assigned ke section + activity)
CREATE TABLE vendor_assignments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  vendor_id UUID NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
  section_id UUID NOT NULL REFERENCES sections(id) ON DELETE CASCADE,
  activity_type_id UUID NOT NULL REFERENCES activity_types(id) ON DELETE CASCADE,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(vendor_id, section_id, activity_type_id)
);

CREATE INDEX idx_vendor_assignments_vendor ON vendor_assignments(vendor_id);
CREATE INDEX idx_vendor_assignments_section ON vendor_assignments(section_id);
CREATE INDEX idx_vendor_assignments_activity ON vendor_assignments(activity_type_id);

-- ============================================================
-- PART 4: PLANNING (REGISTRASI) TABLES
-- ============================================================

-- 12. ACTIVITY PLANS (Header rencana kerja per activity)
CREATE TABLE activity_plans (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  section_id UUID NOT NULL REFERENCES sections(id),
  activity_type_id UUID NOT NULL REFERENCES activity_types(id),
  vendor_id UUID REFERENCES vendors(id) NULL, -- NULL jika material only atau report only
  target_bulan DATE NOT NULL, -- Format: YYYY-MM-01
  stage_id UUID REFERENCES activity_stages(id) NULL,
  alternative_option VARCHAR(50) NULL,
  status VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft', 'approved', 'in_progress', 'completed', 'cancelled')),
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_activity_plans_section ON activity_plans(section_id);
CREATE INDEX idx_activity_plans_activity ON activity_plans(activity_type_id);
CREATE INDEX idx_activity_plans_target_bulan ON activity_plans(target_bulan);
CREATE INDEX idx_activity_plans_status ON activity_plans(status);

-- 13. BLOCK ACTIVITIES (Detail blok per activity plan)
CREATE TABLE block_activities (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  activity_plan_id UUID NOT NULL REFERENCES activity_plans(id) ON DELETE CASCADE,
  block_id UUID NOT NULL REFERENCES blocks(id),
  luas_total DECIMAL(10,2) NOT NULL,
  luas_completed DECIMAL(10,2) DEFAULT 0,
  luas_remaining DECIMAL(10,2),
  status VARCHAR(20) DEFAULT 'planned' CHECK (status IN ('planned', 'in_progress', 'completed', 'cancelled')),
  completed_at TIMESTAMPTZ NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(activity_plan_id, block_id)
);

CREATE INDEX idx_block_activities_plan ON block_activities(activity_plan_id);
CREATE INDEX idx_block_activities_block ON block_activities(block_id);
CREATE INDEX idx_block_activities_status ON block_activities(status);

-- 14. PLANNED MATERIALS (Summary material per activity plan)
CREATE TABLE planned_materials (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  activity_plan_id UUID NOT NULL REFERENCES activity_plans(id) ON DELETE CASCADE,
  material_id UUID NOT NULL REFERENCES materials(id),
  total_quantity DECIMAL(10,3) NOT NULL,
  allocated_quantity DECIMAL(10,3) DEFAULT 0,
  remaining_quantity DECIMAL(10,3),
  unit VARCHAR(20) NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(activity_plan_id, material_id)
);

CREATE INDEX idx_planned_materials_plan ON planned_materials(activity_plan_id);
CREATE INDEX idx_planned_materials_material ON planned_materials(material_id);

-- ============================================================
-- PART 5: TRANSACTION (EXECUTION) TABLES
-- ============================================================

-- 15. TRANSACTIONS (Multiple entries per block)
CREATE TABLE transactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  block_activity_id UUID NOT NULL REFERENCES block_activities(id) ON DELETE CASCADE,
  tanggal DATE NOT NULL,
  luas_dikerjakan DECIMAL(10,2) NOT NULL, -- Bisa partial!
  jumlah_pekerja INTEGER,
  kondisi TEXT,
  catatan TEXT,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_transactions_block_activity ON transactions(block_activity_id);
CREATE INDEX idx_transactions_tanggal ON transactions(tanggal);
CREATE INDEX idx_transactions_created_by ON transactions(created_by);

-- 16. TRANSACTION MATERIALS
CREATE TABLE transaction_materials (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  transaction_id UUID NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
  material_id UUID NOT NULL REFERENCES materials(id),
  quantity_used DECIMAL(10,3) NOT NULL,
  unit VARCHAR(20) NOT NULL,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_transaction_materials_transaction ON transaction_materials(transaction_id);
CREATE INDEX idx_transaction_materials_material ON transaction_materials(material_id);

-- 17. TRANSACTION WORKERS
CREATE TABLE transaction_workers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  transaction_id UUID NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
  worker_id UUID REFERENCES workers(id) NULL, -- NULL jika manual count
  jumlah_manual INTEGER NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_transaction_workers_transaction ON transaction_workers(transaction_id);
CREATE INDEX idx_transaction_workers_worker ON transaction_workers(worker_id);

-- ============================================================
-- PART 6: TRIGGERS FOR AUTO-UPDATE
-- ============================================================

-- Trigger 1: Auto-calculate luas_remaining saat insert block_activities
CREATE OR REPLACE FUNCTION set_initial_luas_remaining()
RETURNS TRIGGER AS $$
BEGIN
  NEW.luas_remaining := NEW.luas_total;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER before_block_activity_insert
BEFORE INSERT ON block_activities
FOR EACH ROW
EXECUTE FUNCTION set_initial_luas_remaining();

-- Trigger 2: Auto-update block_activities setelah transaksi
CREATE OR REPLACE FUNCTION update_block_activity_progress()
RETURNS TRIGGER AS $$
DECLARE
  v_total_completed DECIMAL(10,2);
  v_luas_total DECIMAL(10,2);
BEGIN
  -- Get total luas_dikerjakan
  SELECT 
    COALESCE(SUM(luas_dikerjakan), 0),
    ba.luas_total
  INTO v_total_completed, v_luas_total
  FROM transactions t
  JOIN block_activities ba ON ba.id = t.block_activity_id
  WHERE t.block_activity_id = NEW.block_activity_id
  GROUP BY ba.luas_total;

  -- Update block_activities
  UPDATE block_activities
  SET 
    luas_completed = v_total_completed,
    luas_remaining = v_luas_total - v_total_completed,
    status = CASE
      WHEN v_total_completed >= v_luas_total THEN 'completed'
      WHEN v_total_completed > 0 THEN 'in_progress'
      ELSE 'planned'
    END,
    completed_at = CASE
      WHEN v_total_completed >= v_luas_total THEN NOW()
      ELSE NULL
    END
  WHERE id = NEW.block_activity_id;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER after_transaction_insert
AFTER INSERT ON transactions
FOR EACH ROW
EXECUTE FUNCTION update_block_activity_progress();

-- Trigger 3: Auto-update planned_materials setelah transaction_materials
CREATE OR REPLACE FUNCTION update_material_allocation()
RETURNS TRIGGER AS $$
DECLARE
  v_activity_plan_id UUID;
  v_total_allocated DECIMAL(10,3);
BEGIN
  -- Get activity_plan_id
  SELECT ba.activity_plan_id INTO v_activity_plan_id
  FROM block_activities ba
  JOIN transactions t ON t.block_activity_id = ba.id
  WHERE t.id = NEW.transaction_id;

  -- Calculate total allocated for this material
  SELECT COALESCE(SUM(tm.quantity_used), 0) INTO v_total_allocated
  FROM transaction_materials tm
  JOIN transactions t ON t.id = tm.transaction_id
  JOIN block_activities ba ON ba.id = t.block_activity_id
  WHERE ba.activity_plan_id = v_activity_plan_id
    AND tm.material_id = NEW.material_id;

  -- Update planned_materials
  UPDATE planned_materials
  SET 
    allocated_quantity = v_total_allocated,
    remaining_quantity = total_quantity - v_total_allocated
  WHERE activity_plan_id = v_activity_plan_id
    AND material_id = NEW.material_id;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER after_transaction_material_insert
AFTER INSERT ON transaction_materials
FOR EACH ROW
EXECUTE FUNCTION update_material_allocation();

-- Trigger 4: Auto-update activity_plans status
CREATE OR REPLACE FUNCTION update_activity_plan_status()
RETURNS TRIGGER AS $$
DECLARE
  v_total_blocks INTEGER;
  v_completed_blocks INTEGER;
BEGIN
  -- Count total and completed blocks
  SELECT 
    COUNT(*),
    COUNT(*) FILTER (WHERE status = 'completed')
  INTO v_total_blocks, v_completed_blocks
  FROM block_activities
  WHERE activity_plan_id = NEW.activity_plan_id;

  -- Update activity_plans status
  UPDATE activity_plans
  SET status = CASE
    WHEN v_completed_blocks = v_total_blocks THEN 'completed'
    WHEN v_completed_blocks > 0 THEN 'in_progress'
    ELSE 'approved'
  END
  WHERE id = NEW.activity_plan_id;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER after_block_activity_update
AFTER UPDATE ON block_activities
FOR EACH ROW
WHEN (OLD.status IS DISTINCT FROM NEW.status)
EXECUTE FUNCTION update_activity_plan_status();

-- Trigger 5: Auto-calculate planned_materials remaining_quantity
CREATE OR REPLACE FUNCTION set_initial_remaining_quantity()
RETURNS TRIGGER AS $$
BEGIN
  NEW.remaining_quantity := NEW.total_quantity;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER before_planned_material_insert
BEFORE INSERT ON planned_materials
FOR EACH ROW
EXECUTE FUNCTION set_initial_remaining_quantity();

-- ============================================================
-- PART 7: VIEWS FOR EASY QUERYING
-- ============================================================

-- View: Complete Block Info
CREATE OR REPLACE VIEW v_blocks_complete AS
SELECT 
  b.*,
  COUNT(ba.id) FILTER (WHERE ba.status = 'planned') as planned_count,
  COUNT(ba.id) FILTER (WHERE ba.status = 'in_progress') as in_progress_count,
  COUNT(ba.id) FILTER (WHERE ba.status = 'completed') as completed_count
FROM blocks b
LEFT JOIN block_activities ba ON ba.block_id = b.id
GROUP BY b.id;

-- View: Activity Plan Progress
CREATE OR REPLACE VIEW v_activity_plan_progress AS
SELECT 
  ap.*,
  s.name as section_name,
  at.name as activity_name,
  v.name as vendor_name,
  ast.name as stage_name,
  COUNT(ba.id) as total_blocks,
  COUNT(ba.id) FILTER (WHERE ba.status = 'completed') as completed_blocks,
  SUM(ba.luas_total) as total_luas,
  SUM(ba.luas_completed) as completed_luas,
  ROUND(
    (SUM(ba.luas_completed) / NULLIF(SUM(ba.luas_total), 0) * 100)::numeric, 2
  ) as progress_percentage
FROM activity_plans ap
JOIN sections s ON s.id = ap.section_id
JOIN activity_types at ON at.id = ap.activity_type_id
LEFT JOIN vendors v ON v.id = ap.vendor_id
LEFT JOIN activity_stages ast ON ast.id = ap.stage_id
LEFT JOIN block_activities ba ON ba.activity_plan_id = ap.id
GROUP BY ap.id, s.name, at.name, v.name, ast.name;

-- View: Material Usage Summary
CREATE OR REPLACE VIEW v_material_usage_summary AS
SELECT 
  pm.*,
  m.code as material_code,
  m.name as material_name,
  m.category as material_category,
  ap.target_bulan,
  s.name as section_name,
  at.name as activity_name,
  ROUND(
    (pm.allocated_quantity / NULLIF(pm.total_quantity, 0) * 100)::numeric, 2
  ) as usage_percentage
FROM planned_materials pm
JOIN materials m ON m.id = pm.material_id
JOIN activity_plans ap ON ap.id = pm.activity_plan_id
JOIN sections s ON s.id = ap.section_id
JOIN activity_types at ON at.id = ap.activity_type_id;

-- ============================================================
-- DONE! Schema is ready to use
-- ============================================================
